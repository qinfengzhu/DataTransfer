Stat/Transfer Version Nine Readme File

Version 9.03.07.06.21

The default output format for writing Stata files was changed in 9.03 to Stata 10. 
This unfortunately created some confusion and difficulty, particularly for command
processor users.  This release adds a warning message and a new command line switch.

 /vy will cause Stata Version 9 to be output and is equivalent to
				set write-old-ver y
	
Additionally, you can set a version explicity, as in /v9.  Therefore if you want to write
a Version 9 Stata/SE file type:

	copy in.xxx stata/se out.dta /v9
	
The installer has been changed in this release to accept a new parameter, "noservice".  If you 
are running on XP (but not on Vista) and do not have sufficient privilages to install a 
service, run the installer with this parameter and you will get the old update mechanism.



Version 9.03

Support for Stata Version 10.
Stata Time (%tchxx) and DateTime (%tc and %tC) values are now supported.
Leapseconds in %tC variables are automatically removed when the file is read.


Version 9.02

Licensing mechanism was changed so that annual lease licensees can run
Stat/Transfer from a network server.


Verison 9.01 - Initial Release

